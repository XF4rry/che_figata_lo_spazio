var express = require('express');
var app=express();
const ejs=require('axios');
const bodyParser=require('body-parser');
const {default:axios}=require('axios');
const {name}=require('ejs')
app.set('view engine','ejs');
app.use(bodyParser.urlencoded({
    extended:true
}));
app.use(express.static(__dirname+'/public'));

app.get('/',function(req,res){
    var iscritti=[
        {nome:'Sammy',organizzazione:"DigitalOcean",bannodinascita:2021,img:"https://static.sky.it/images_static/tg24/spettacolo/2018/06/07/Kanye_West/GettyImages-_Kanye_West__3_.jpg.transform/gallery-horizontal-mobile/5653584e5933ec44dada0049795e218477894bae/img.jpeg"},
        {nome:'Tux',organizzazione:"Linux",bannodinascita:1996,img:"https://i8.amplience.net/i/naras/jpegmafia_gettyimages-1157222914_sm.jpg.jpg?w=821&sm=c"},
        {nome:'Moby&Dock',organizzazione:"Docker",bannodinascita:2013,img:"https://www.outpump.com/wp-content/uploads/2020/04/lil-uzi-playboi-carti-outpump-scaled.jpeg"}
    ];

    var stringadainviare="questa è una stringa generica";

    res.render('pages/index',{
        utenti:iscritti,
        stringa:stringadainviare
    });
});
var immg='';
app.get('/nasa',function(req,res){
    var apiKey='0xhga0V6QkjVg6KcPA3TRzZJRYeEArNv4AUrI8pd';
    const apiUrl =`https://api.nasa.gov/planetary/apod?api_key=0xhga0V6QkjVg6KcPA3TRzZJRYeEArNv4AUrI8pd`
   
    var id='';
    var title='';

    axios.get(apiUrl)
    .then(function(response){
    const nasadata=response.data
         immg=nasadata.hdurl
            res.render('pages/nasa',{
                immg,
                id,
                title
            });
           
            
    });
 })

app.get('/gol',function(req,res){
    res.render('pages/gol')
})

 app.post('/nasa',function(req,res){
    var apiUrl="https://eonet.gsfc.nasa.gov/api/v3/events";
    var num=parseInt(req.body.numm)
    
    axios.get(apiUrl)
    .then(function(response){
        const nasadata=response.data.events
        var id=nasadata[num].id
        var title=nasadata[num].title
        
        
            res.render('pages/nasa',{
                id,
                title,
                num,
                immg
            });
            console.log(id)

    })

 })

 app.get('/contact',function(req,res){
    
    res.render('pages/contact')
        
 })

 
app.post("/contact", function(req, res){
    var name = req.body.nome;
    var email = req.body.emaiil;
    var message = req.body.messageee;
    
    console.log("Nome:", name);
    console.log("Email:", email);
    console.log("Messaggio:", message);
    
});



app.get("/kanye",function(req,res){
    var apiUrl='https://api.kanye.rest'
    var neg='';
    axios.get(apiUrl)
    .then(function(response){
        const kanyedata=response.data
        neg=kanyedata.quote
        res.render("pages/kanye",{
            neg
        })
    })
    
})

app.listen(5000);
console.log('server in ascolto sulla porta 5000')